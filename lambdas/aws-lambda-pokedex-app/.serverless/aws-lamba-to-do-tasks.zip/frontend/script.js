document.getElementById('myForm').addEventListener('submit', function(event) {
    event.preventDefault();

    const title = document.getElementById('title').value;
    const description = document.getElementById('description').value;
    const createdAt = document.getElementById('createdAt').value;

    const data = {
        title: title,
        description: description,
        createdAt: createdAt
    };

    fetch('https://px5e6p3197.execute-api.us-east-1.amazonaws.com/tasks', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify(data),
    })
    .then(response => {
        if (!response.ok) {
            throw new Error('Error en la red');
        }
        return response.json();
    })
    .then(data => {
        const output = `
            <h2>Datos Enviados:</h2>
            <p><strong>Id:</strong> ${data.id}</p>
            <p><strong>Título:</strong> ${data.title}</p>
            <p><strong>Descripción:</strong> ${data.description}</p>
            <p><strong>Fecha de Creación:</strong> ${data.createdAt}</p>
        `;
        document.getElementById('output').innerHTML = output;
    })
    .catch(error => {
        document.getElementById('output').innerHTML = `<p>Error: ${error.message}</p>`;
    });

    // Opcional: limpiar el formulario
    this.reset();
});